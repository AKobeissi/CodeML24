import pandas as pd
import numpy as np
import glob
import os
import datetime as dt

dem_data = np.loadtxt("/Users/danilgarmaev/Documents/Fall 2024 M.Sc. AI/Ericsson/data/Hackathon_data/DEM_ASC_Hackathon/SQC_DEM_ASC.asc", skiprows=6)
print(dem_data)
print(dem_data.shape)

water_level_data = pd.read_csv("/Users/danilgarmaev/Documents/Fall 2024 M.Sc. AI/Ericsson/data/Hackathon_data/Hackathon_water_level_train_set/water_level_train.csv")
print(water_level_data.head())

rainfall_files = "/Users/danilgarmaev/Documents/Fall 2024 M.Sc. AI/Ericsson/data/Hackathon_data/Hackathon_rainfall_train_set"  # Adjust the path
rainfall_data = {}

if 'time' in water_level_data.columns:
    water_level_data['time'] = pd.to_datetime(water_level_data['time'])




for filename in os.listdir(rainfall_files):
    # Extract the point_id from the filename (e.g., T0101R)
    # point_id = file.split('\\')[-1].split('R')[0] + 'R'  # Extracting T0101R from T0101R.csv_train.csv

    if filename.startswith('T'):
        # Extract the x and y coordinates from the filename
        name  = filename[:5]
        file_path = os.path.join(rainfall_files, filename)        
        # Store the dataframe in the dictionary with (x, y) as the key
        rainfall_data[name] = pd.read_csv(file_path)

    rainfall_data[name] = pd.read_csv(file_path)
    if 'time' in rainfall_data[name].columns:
            rainfall_data[name]['time'] = pd.to_datetime(rainfall_data[name]['time'])

    if 'rate' in rainfall_data[name].columns:
        # Group by date and fill null values
        rainfall_data[name]['rate'] = rainfall_data[name].groupby(rainfall_data[name]['time'].dt.date)['rate'].transform(lambda x: x.fillna(x.mean()))


# #Not necessary for NaN filling
# for point_id, df in rainfall_data.items():
#     if 'time' in df.columns:
#         df['time'] = pd.to_datetime(df['time'])

#     # Now, merge with the water level data
#     combined_data = pd.merge(df, water_level_data, on='time', how='inner')

#     # Optionally, you can check the result of the merge
#     print(f"Combined data for {point_id}:")
#     print(combined_data.head()) 
    