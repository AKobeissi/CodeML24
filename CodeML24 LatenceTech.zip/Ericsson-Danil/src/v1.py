import pandas as pd
import numpy as np

import os
import re

directory1 = '/Users/danilgarmaev/Documents/Fall 2024 M.Sc. AI/Ericsson/data/Hackathon_data/Hackathon_Rain_Location_OFF' 
directory2 = '/Users/danilgarmaev/Documents/Fall 2024 M.Sc. AI/Ericsson/data/Hackathon_data/Hackathon_rainfall_train_set'  


# Function to convert the grid point format
def convert_point_format_Rain_loc(filename):
    # Regex to match the P(x,y) format
    match = re.match(r'P(\d)(\d{1,2})', filename)
    if match:
        x, y = match.groups()
        if x == '0' and y == '0':
            new_x = '10'
            new_y = '10'
        elif x == '0':
            new_x = '10'
            new_y = str(int(y)).zfill(2)
        elif y == '0':
            new_x = str(int(x)).zfill(2)
            new_y = '10'
        

        else:
        # Convert x and y, replacing '0' with '10'
            new_x = str(int(x)).zfill(2)  # Add 1 to x and pad with zeros
            new_y = str(int(y)).zfill(2)  # Add 1 to y and pad with zeros

        return f'P{new_x}{new_y}.csv'
    return None
# Directory containing the files to be renamed

# Loop through each file in the directory
for filename in os.listdir(directory1):
    if filename.startswith('P') and filename.endswith(''):
        new_filename = convert_point_format_Rain_loc(filename)
        if new_filename:
            # Create full file paths
            old_file_path = os.path.join(directory1, filename)
            new_file_path = os.path.join(directory1, new_filename)
            # Rename the file
            os.rename(old_file_path, new_file_path)
            print(f'Renamed: {filename} -> {new_filename}')
    folder_path = 'path_to_your_folder'


# Function to convert the grid point format
def convert_point_format_Rain_level(filename):
    # Regex to match the P(x,y) format
    match = re.match(r'T(\d)(\d{1,2})R.csv_train', filename)
    if match:
        x, y = match.groups()
        if x == '0' and y == '0':
            new_x = '10'
            new_y = '10'

        elif x == '0':
            new_x = '10'
            new_y = str(int(y)).zfill(2)
        elif y == '0':
            new_x = str(int(x)).zfill(2)
            new_y = '10'
        
        else:
        # Convert x and y, replacing '0' with '10'
            new_x = str(int(x)).zfill(2)  # Add 1 to x and pad with zeros
            new_y = str(int(y)).zfill(2)  # Add 1 to y and pad with zeros

        return f'T{new_x}{new_y}R.csv_train.csv'
    return None
# Directory containing the files (Name to your path)

# Loop through each file in the directory
for filename in os.listdir(directory2):
    if filename.startswith('T'): #and filename.endswith('R.csv_train'):
        new_filename = convert_point_format_Rain_level(filename)
        if new_filename:
            # Create full file paths
            old_file_path = os.path.join(directory2, filename)
            new_file_path = os.path.join(directory2, new_filename)
            # Rename the file
            os.rename(old_file_path, new_file_path)
            print(f'Renamed: {filename} -> {new_filename}')
    
